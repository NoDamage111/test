<template>
  <v-container>
    <v-card class="pa-6">
      <template v-if="proposalsStore.isLoading && !proposalsStore.currentProposal">
        <v-progress-circular indeterminate></v-progress-circular>
      </template>
      
      <template v-else-if="proposalsStore.error">
        <v-alert type="error">{{ proposalsStore.error }}</v-alert>
      </template>
      
      <template v-else-if="proposalsStore.currentProposal">
        <v-card-title class="text-h4 mb-2">
          {{ proposalsStore.currentProposal.title }}
        </v-card-title>
        
        <v-card-subtitle class="text-h6 mb-4">
          Создано: {{ new Date(proposalsStore.currentProposal.created_at).toLocaleDateString() }}
        </v-card-subtitle>
        
        <v-card-text>
          <p class="text-body-1 mb-6">
            {{ proposalsStore.currentProposal.description || 'Описание отсутствует' }}
          </p>
          
          <v-divider class="my-4"></v-divider>
          
          <v-card-title class="text-h5 pa-0 mb-4">
            Выбранные вентиляторы
          </v-card-title>
          
          <v-alert
            v-if="!proposalsStore.currentProposal.proposal_fans?.length"
            type="info"
          >
            Вентиляторы не добавлены
          </v-alert>
          
          <v-list v-else>
            <v-list-item
              v-for="fan in proposalsStore.currentProposal.proposal_fans"
              :key="fan.id"
              class="mb-4"
            >
              <template v-slot:prepend>
                <v-icon icon="mdi-fan" color="primary"></v-icon>
              </template>
              
              <v-list-item-title class="text-h6">
                {{ fan.fan_data["Модель колеса"] }}
              </v-list-item-title>
              
              <v-list-item-subtitle class="mt-2">
                <v-chip
                  v-for="(value, key) in {
                    'Расход': `${fan.fan_data.crossPoint[0].x} м³/ч`,
                    'Давление': `${fan.fan_data.crossPoint[0].y} Па`,
                    'Мощность': `${fan.fan_data.crossPoint[0].power} кВт`,
                    'КПД': `${fan.fan_data.crossPoint[0].kpd} %`
                  }"
                  :key="key"
                  class="mr-2 mb-2"
                  size="small"
                >
                  {{ key }}: {{ value }}
                </v-chip>
              </v-list-item-subtitle>

               <template v-slot:append>
              <!-- Кнопка "Данные" -->
              <v-btn
                color="primary"
                variant="outlined"
                class="ml-2"
                @click="showFanDetails(fan)"
              >
                Данные
              </v-btn>
            </template>

            </v-list-item>
          </v-list>
          
<v-dialog
          v-model="showFanDialog"
          max-width="800px"
          scrollable
        >
          <v-card>
            <v-card-title class="d-flex justify-space-between align-center">
              <span>Технические данные вентилятора</span>
              <v-btn
                icon
                @click="showFanDialog = false"
              >
                <v-icon>mdi-close</v-icon>
              </v-btn>
            </v-card-title>

            <v-card-text>
              <div v-if="selectedFanData">
                <v-list>
                  <v-list-item>
                    <v-list-item-title class="text-h6">
                      {{ selectedFanData.fan_data['Модель колеса'] }}
                    </v-list-item-title>
                    <v-list-item-subtitle>
                      {{ selectedFanData.fan_data['Тип вентилятора'] }}
                    </v-list-item-subtitle>
                  </v-list-item>

                  <v-divider class="my-2"></v-divider>

<v-list-item>
  <v-list-item-title>Основные параметры:</v-list-item-title>
</v-list-item>

<v-list-item>
  <div class="parameters-list">
    <div class="parameter-item">
      <span class="parameter-label">Фактический расход:</span>
      <span class="parameter-value">{{ selectedFanData.fan_data?.crossPoint?.[0]?.x || 'Н/Д' }} м³/ч</span>
    </div>
    <div class="parameter-item">
      <span class="parameter-label">Фактическое давление:</span>
      <span class="parameter-value">{{ selectedFanData.fan_data?.crossPoint?.[0]?.y || 'Н/Д' }} Па</span>
    </div>
    <div class="parameter-item">
      <span class="parameter-label">Мощность:</span>
      <span class="parameter-value">{{ selectedFanData.fan_data?.crossPoint?.[0]?.power || 'Н/Д' }} кВт</span>
    </div>
    <div class="parameter-item">
      <span class="parameter-label">КПД:</span>
      <span class="parameter-value">{{ selectedFanData.fan_data?.crossPoint?.[0]?.kpd || 'Н/Д' }} %</span>
    </div>
    <div class="parameter-item">
      <span class="parameter-label">Скорость вращения:</span>
      <span class="parameter-value">{{ selectedFanData.fan_data?.speed || 'Н/Д' }} об/мин</span>
    </div>
  </div>
</v-list-item>

                  <!-- График -->
                  <v-list-item>
                    <v-card class="mt-4" flat>
                      <v-card-title class="text-subtitle-1">
                        Аэродинамическая характеристика
                      </v-card-title>
                      <v-card-text>
                        <div class="chart-container">
                          <img 
                            :src="selectedFanData.fan_data.graph.graph.base64" 
                            alt="Аэродинамическая характеристика"
                            style="max-width: 100%; height: auto;"
                          />
                        </div>
                      </v-card-text>
                    </v-card>
                  </v-list-item>

                  <v-list-item>
                    <v-list-item-title>Примечание:</v-list-item-title>
                    <v-list-item-subtitle>
                      <div>{{ selectedFanData.fan_data.require?.notice || 'Нет примечания' }}</div>
                    </v-list-item-subtitle>
                  </v-list-item>
                </v-list>
              </div>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn
                color="primary"
                @click="showFanDialog = false"
              >
                Закрыть
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>

          <v-divider class="my-4"></v-divider>

        </v-card-text>
        
        <v-card-actions>
          <v-btn
            to="/proposals"
            variant="text"
            color="grey"
          >
            Назад к списку
          </v-btn>
        </v-card-actions>
      </template>
      
      <template v-else>
        <v-alert type="warning">Предложение не найдено</v-alert>
      </template>
    </v-card>
  </v-container>
</template>

<script setup>
import { onMounted, watch } from 'vue'
import { useProposalsStore } from '@/stores/proposals'
import { useRoute } from 'vue-router'
import { ref } from 'vue'

const proposalsStore = useProposalsStore()
const route = useRoute()

const showFanDialog = ref(false)
const selectedFanData = ref(null)

onMounted(() => {
  loadProposal()
})

watch(() => route.params.id, () => {
  loadProposal()
})

const loadProposal = async () => {
  if (route.params.id) {
    await proposalsStore.fetchProposalById(route.params.id)
  }
}

const showFanDetails = (fan) => {
  console.log(fan);
  
  selectedFanData.value = fan
  showFanDialog.value = true
}

const calculateTotal = () => {
  if (!proposalsStore.currentProposal?.proposal_fans) return 0
  
  return proposalsStore.currentProposal.proposal_fans.reduce((total, fan) => {
    return total + (fan.fan_data.price * fan.quantity)
  }, 0)
}
</script>