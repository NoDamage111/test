const express = require('express')
const router = express.Router()
const { createClient } = require('@supabase/supabase-js')
const config = require('../config')

const supabase = createClient(config.supabaseUrl, config.supabaseKey)

// Middleware to verify JWT
const verifyToken = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1]
  
  if (!token) {
    return res.status(401).json({ error: 'Authorization token required' })
  }
  
  try {
    const { data: { user }, error } = await supabase.auth.getUser(token)
    
    if (error) throw error
    
    req.user = user
    next()
  } catch (error) {
    res.status(401).json({ error: 'Invalid or expired token' })
  }
}

// Get user profile
router.get('/', verifyToken, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', req.user.id)
      .single()
    
    if (error) throw error
    
    res.json(data)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Update user profile
router.put('/', verifyToken, async (req, res) => {
  try {
    const { name, avatar_url } = req.body
    
    const { data, error } = await supabase
      .from('profiles')
      .update({ name, avatar_url })
      .eq('id', req.user.id)
      .select()
      .single()
    
    if (error) throw error
    
    res.json(data)
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

module.exports = router